import "./globals.css";

export const metadata = {
  title: "ATO Lab — Pre-Account Takeover",
  description: "Educational lab for pre-account takeover / account collision. Not a real target.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
