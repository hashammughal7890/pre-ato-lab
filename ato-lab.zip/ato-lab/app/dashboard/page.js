"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

function AttackerReport() {
  return (
    <div className="report">
      <h2>Title</h2>
      <p>
        Pre-Account Takeover: Unverified Email/Password Signup Remains Valid
        After Email Identity is Activated via Google OAuth
      </p>

      <h2>Summary</h2>
      <p>
        The application’s email/password registration flow creates an account
        and sets a password immediately upon submission, before the user
        completes OTP verification. This unverified account remains in a
        persistent, accessible state. Separately, when a Google sign-in is
        completed using the same email address — even from a completely
        different session, device, or location — the application treats the
        email as now “activated,” without invalidating or re-checking the
        original unverified password-based account. As a result, the original
        password remains fully valid and grants complete account access,
        despite its OTP step never having been completed.
      </p>

      <h2>Weakness</h2>
      <p>
        CWE-287: Improper Authentication (combined with CWE-613: Insufficient
        Session/Credential Expiration) — this specific pattern (an unverified
        credential silently gaining validity through an unrelated verification
        event) is a variant of the Pre-Account Takeover class.
      </p>

      <h2>Steps to Reproduce</h2>
      <ol className="list">
        <li>
          Go to [target] and register a new account using an email address and
          password (normal registration flow).
        </li>
        <li>
          On the OTP verification screen, do not enter the OTP. Leave this
          tab/session open and unverified.
        </li>
        <li>
          Open a separate private/incognito browser tab (simulating a different
          device/location).
        </li>
        <li>
          In this new private tab, register using “Continue with Google,”
          signing in with a Google account that uses the exact same email
          address as Step 1.
        </li>
        <li>Allow this Google registration to complete normally.</li>
        <li>
          Go back to the original browser tab/session from Step 1 (the one still
          sitting on the unverified OTP screen).
        </li>
        <li>
          Refresh, or re-attempt login using the original email and password
          credentials from Step 1.
        </li>
        <li>
          Result: The account logs in successfully and grants full access —
          even though the OTP from Step 1 was never entered and the
          email/password account was never independently verified.
        </li>
      </ol>

      <h2>Expected Result</h2>
      <p>
        The email/password account from Step 1 should remain locked/unverified
        and inaccessible until its own OTP is completed, regardless of any
        unrelated Google sign-in activity using the same email.
      </p>

      <h2>Impact</h2>
      <p>
        This allows a password set during an incomplete, unverified registration
        to silently become valid as soon as the same email is verified through a
        completely separate channel (Google OAuth), with no connection between
        the two events other than the matching email address:
      </p>
      <ul className="list">
        <li>
          An attacker can set up an account with a target’s email and a password
          of their choosing, then simply wait. As soon as the real owner signs
          in with Google at any point in the future — from any device, any
          location — the attacker’s original password becomes a fully working
          credential for that same account.
        </li>
        <li>
          The real account owner has no reason to suspect anything is wrong,
          since their own sign-in (via Google) completed normally and
          successfully.
        </li>
        <li>
          This requires no access to the victim’s inbox, phone, or any OTP at
          any stage — the attacker’s access path is entirely independent of the
          victim’s actual verification.
        </li>
        <li>
          Because the two signup paths (password-based and OAuth-based) are not
          validated against each other, this effectively allows an attacker to
          plant persistent, undetected access to an account before the real user
          even finishes setting it up.
        </li>
      </ul>
    </div>
  );
}

export default function DashboardPage() {
  const router = useRouter();
  const [session, setSession] = useState(null);

  useEffect(() => {
    const raw = localStorage.getItem("ato_session");
    if (!raw) {
      router.replace("/login");
      return;
    }
    try {
      setSession(JSON.parse(raw));
    } catch {
      router.replace("/login");
    }
  }, [router]);

  function logout() {
    localStorage.removeItem("ato_session");
    router.push("/login");
  }

  function resetLab() {
    localStorage.removeItem("ato_session");
    localStorage.removeItem("ato_account");
    localStorage.removeItem("ato_pending");
    router.push("/");
  }

  if (!session) {
    return (
      <main className="container">
        <div className="card">
          <p>Loading…</p>
        </div>
      </main>
    );
  }

  const isAttacker = session.source === "login";

  // Victim path: welcome only + note + login button
  if (!isAttacker) {
    return (
      <main className="container">
        <div className="card">
          <div className="badge">Victim account</div>
          <h1>Welcome, victim account</h1>
          <p className="subtitle">
            Signed in as <span className="mono">{session.email}</span>
          </p>

          <div className="note">
            <strong>Note:</strong> Now sign in with the same email and password
            the attacker used during form registration, using the button below.
          </div>

          <div className="row">
            <button
              type="button"
              className="btn btn-primary"
              onClick={() => {
                localStorage.removeItem("ato_session");
                router.push("/login");
              }}
            >
              Go to Login
            </button>
            <button type="button" className="btn btn-ghost" onClick={resetLab}>
              Reset lab
            </button>
          </div>
        </div>
      </main>
    );
  }

  // Attacker path: full report + roast + educational disclaimer
  return (
    <main className="container">
      <div className="card">
        <div className="badge">Attacker account · Password login</div>
        <h1>Welcome, {session.name}</h1>
        <p className="subtitle">
          Signed in as <span className="mono">{session.email}</span> with the
          planted password.
        </p>

        <AttackerReport />

        <div className="roast">
          <p>This is the only reason they left you.</p>
        </div>

        <div className="note">
          <strong>Note:</strong> This is for educational purposes only. It
          should only be tested on bug bounty programs where such testing is
          allowed.
        </div>

        <div className="row">
          <button type="button" className="btn btn-ghost" onClick={logout}>
            Logout
          </button>
          <button type="button" className="btn btn-primary" onClick={resetLab}>
            Reset lab
          </button>
        </div>
      </div>
    </main>
  );
}
