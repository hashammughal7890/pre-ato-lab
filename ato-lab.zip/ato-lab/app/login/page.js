"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  function onLogin(e) {
    e.preventDefault();
    setError("");

    const raw = localStorage.getItem("ato_account");
    if (!raw) {
      setError(
        "No active account found. Complete form registration, leave verification, then continue with Google using the same email."
      );
      return;
    }

    let account;
    try {
      account = JSON.parse(raw);
    } catch {
      setError("Lab state is invalid. Please reset and try again.");
      return;
    }

    if (!account.live) {
      setError("This account is not active yet.");
      return;
    }

    const normalized = email.trim().toLowerCase();
    if (normalized !== account.email) {
      setError("Email does not match the account created in this lab session.");
      return;
    }

    if (!account.password) {
      setError("No password is available for this account.");
      return;
    }

    if (password !== account.password) {
      setError("Incorrect password.");
      return;
    }

    localStorage.setItem(
      "ato_session",
      JSON.stringify({
        name: account.name,
        email: account.email,
        source: "login",
        loggedInAt: Date.now(),
      })
    );
    router.push("/dashboard");
  }

  return (
    <main className="container">
      <div className="card">
        <div className="badge">Password login</div>
        <h1>Sign in</h1>
        <p className="subtitle">
          Sign in with the same email and password used during form
          registration.
        </p>

        <form className="form" onSubmit={onLogin}>
          <label>
            Email
            <input
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Email used during registration"
            />
          </label>
          <label>
            Password
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password from form registration"
            />
          </label>

          {error ? <div className="danger-note">{error}</div> : null}

          <button type="submit" className="btn btn-primary">
            Login
          </button>
        </form>

        <div className="row">
          <button
            type="button"
            className="btn btn-ghost"
            onClick={() => router.push("/")}
          >
            Back to register
          </button>
        </div>
      </div>
    </main>
  );
}
