"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

function isValidEmail(v) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
}

export default function GooglePage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");

  function onContinue(e) {
    e.preventDefault();
    setError("");

    if (!isValidEmail(email.trim())) {
      setError("Please enter a valid email address.");
      return;
    }

    const normalized = email.trim().toLowerCase();
    const pendingRaw = localStorage.getItem("ato_pending");

    if (!pendingRaw) {
      setError(
        "No pending form registration found. Register with the email form first, then continue with the same email here."
      );
      return;
    }

    let pending;
    try {
      pending = JSON.parse(pendingRaw);
    } catch {
      setError("Lab state is invalid. Please register again from the form.");
      return;
    }

    // Critical fix: Google path only works with the exact email used on form signup
    if (pending.email !== normalized) {
      setError(
        "This email does not match the address used during form registration. Use the same email to continue."
      );
      return;
    }

    const account = {
      name: pending.name,
      email: pending.email,
      password: pending.password,
      live: true,
      via: "google",
      liveAt: Date.now(),
    };
    localStorage.setItem("ato_account", JSON.stringify(account));

    localStorage.setItem(
      "ato_session",
      JSON.stringify({
        name: account.name,
        email: account.email,
        source: "google",
        loggedInAt: Date.now(),
      })
    );

    router.push("/dashboard");
  }

  return (
    <main className="container">
      <div className="card">
        <div className="badge">Continue with Google</div>
        <h1>Continue with Google</h1>
        <p className="subtitle">
          Simulated Google signup for this lab. Enter the same email used on the
          form registration.
        </p>

        <form className="form" onSubmit={onContinue}>
          <label>
            Email
            <input
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Same email as form registration"
              autoComplete="email"
            />
          </label>

          {error ? <div className="danger-note">{error}</div> : null}

          <button type="submit" className="btn btn-primary">
            Continue
          </button>
        </form>

        <div className="note">
          <strong>Note:</strong> Only the email used during form signup will
          activate the account here. A different address will not work.
        </div>

        <div className="row">
          <button
            type="button"
            className="btn btn-ghost"
            onClick={() => router.push("/")}
          >
            Back
          </button>
        </div>
      </div>
    </main>
  );
}
