"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

function isValidEmail(v) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
}

export default function RegisterPage() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  function onFormSubmit(e) {
    e.preventDefault();
    setError("");

    if (!name.trim() || !email.trim() || !password) {
      setError("Name, email, and password are required.");
      return;
    }
    if (!isValidEmail(email.trim())) {
      setError("Please enter a valid email address.");
      return;
    }
    if (password.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }

    const pending = {
      name: name.trim(),
      email: email.trim().toLowerCase(),
      password,
      createdAt: Date.now(),
    };
    localStorage.setItem("ato_pending", JSON.stringify(pending));
    router.push("/otp");
  }

  return (
    <main className="container">
      <div className="card">
        <div className="badge">Educational lab</div>
        <h1>Create your account</h1>

        <button
          type="button"
          className="btn btn-google"
          onClick={() => router.push("/google")}
        >
          Continue with Google
        </button>

        <div className="divider">or register with email</div>

        <form className="form" onSubmit={onFormSubmit}>
          <label>
            Name
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your name"
              autoComplete="name"
            />
          </label>
          <label>
            Email
            <input
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="victim@example.com"
              autoComplete="email"
            />
          </label>
          <label>
            Password
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Choose a password"
              autoComplete="new-password"
            />
          </label>

          {error ? <div className="danger-note">{error}</div> : null}

          <button type="submit" className="btn btn-primary">
            Create account
          </button>
        </form>

        <div className="note">
          <strong>Note:</strong> Start by entering any name and password you like,
          but use the victim&apos;s email address for this step.
        </div>

        <div className="row">
          <button
            type="button"
            className="btn btn-ghost"
            onClick={() => router.push("/login")}
          >
            Login
          </button>
        </div>

        <p className="footer">
          For learning only. No real OAuth or email delivery is used.
        </p>
      </div>
    </main>
  );
}
