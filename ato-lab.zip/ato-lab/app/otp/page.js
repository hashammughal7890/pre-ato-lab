"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";

export default function OtpPage() {
  const router = useRouter();
  const [pending, setPending] = useState(null);
  const [digits, setDigits] = useState(["", "", "", "", "", ""]);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    const raw = localStorage.getItem("ato_pending");
    if (!raw) {
      setMsg("No pending registration found. Go back and register with the form first.");
      return;
    }
    try {
      setPending(JSON.parse(raw));
    } catch {
      setMsg("Something went wrong with lab state. Please register again.");
    }
  }, []);

  const pin = useMemo(() => digits.join(""), [digits]);

  function onDigit(i, value) {
    const v = value.replace(/\D/g, "").slice(-1);
    const next = [...digits];
    next[i] = v;
    setDigits(next);
  }

  function onVerify(e) {
    e.preventDefault();
    if (!pending) return;

    if (pin.length !== 6) {
      setMsg("Enter the 6-digit verification code.");
      return;
    }

    setMsg(
      "The attacker does not know this code. Leave this step and continue as the victim using Continue with Google below."
    );
  }

  return (
    <main className="container">
      <div className="card">
        <div className="badge">Email verification</div>
        <h1>Enter verification code</h1>
        <p className="subtitle">
          A 6-digit code would normally be sent to the account email.
        </p>

        {pending ? (
          <div className="kv">
            <div>
              <span>Name</span>
              <span>{pending.name}</span>
            </div>
            <div>
              <span>Email</span>
              <span className="mono">{pending.email}</span>
            </div>
          </div>
        ) : null}

        <form className="form" onSubmit={onVerify}>
          <div className="pin-box">
            {digits.map((d, i) => (
              <input
                key={i}
                inputMode="numeric"
                maxLength={1}
                value={d}
                onChange={(e) => onDigit(i, e.target.value)}
              />
            ))}
          </div>
          <button type="submit" className="btn btn-primary">
            Verify code
          </button>
        </form>

        <div className="note warn-note">
          <strong>Note:</strong> The attacker&apos;s part is done here because they
          do not know the one-time code. It is the victim&apos;s turn now —
          continue as the victim and register with the Google button below.
        </div>

        <div className="row">
          <button
            type="button"
            className="btn btn-ghost"
            onClick={() => router.push("/google")}
          >
            Continue with Google
          </button>
          <button
            type="button"
            className="btn btn-ghost"
            onClick={() => router.push("/login")}
          >
            Login
          </button>
          <button
            type="button"
            className="btn btn-ghost"
            onClick={() => router.push("/")}
          >
            Back
          </button>
        </div>

        {msg ? <div className="note danger-note">{msg}</div> : null}
      </div>
    </main>
  );
}
